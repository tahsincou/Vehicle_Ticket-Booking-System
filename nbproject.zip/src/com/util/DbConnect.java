package com.util;

import java.sql.*;
import java.util.*;

public class DbConnect {

    public static Connection getConnect() throws SQLException {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            return DriverManager.getConnection("jdbc:mysql://localhost:3306/invent", "root", "1234");
        } catch (ClassNotFoundException ex) {
            return null;
        }
    }
}
