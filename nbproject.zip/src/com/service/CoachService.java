package com.service;

import com.common.CommonDao;
import com.common.CommonService;
import com.dao.CoachDao;
import com.model.CoachModel;
import java.util.List;

public class CoachService implements CommonService<CoachModel> {

    CommonDao cDao = new CoachDao();

    @Override
    public int save(CoachModel t) {
        return cDao.save(t);
    }

    @Override
    public int search(CoachModel t) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int update() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<CoachModel> getAll() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
