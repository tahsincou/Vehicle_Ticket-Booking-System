package com.service;

import com.common.CommonDao;
import com.common.CommonService;
import com.dao.FindBusDao;
import com.model.CoachModel;
import java.util.List;

public class FindBusService implements CommonService<CoachModel> {

    CommonDao fDao = new FindBusDao();

    @Override
    public int save(CoachModel t) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int search(CoachModel t) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int update() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<CoachModel> getAll() {
        return fDao.getAll();
    }

}
