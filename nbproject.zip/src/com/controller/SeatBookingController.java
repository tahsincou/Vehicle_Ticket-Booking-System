package com.controller;

import com.common.CommonService;
import com.model.CoachModel;
import com.service.CoachService;
import javax.swing.JOptionPane;

public class SeatBookingController extends javax.swing.JFrame {

    CommonService cServ;
    String Name, Destination, time, Code;
    int Price = 0;

    public SeatBookingController() {
        initComponents();

        getAll();
        cServ = new CoachService();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        Title = new javax.swing.JPanel();
        busName = new javax.swing.JLabel();
        btnBook = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        st1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        st2 = new javax.swing.JLabel();
        st3 = new javax.swing.JLabel();
        st4 = new javax.swing.JLabel();
        st5 = new javax.swing.JLabel();
        st6 = new javax.swing.JLabel();
        st7 = new javax.swing.JLabel();
        st8 = new javax.swing.JLabel();
        st9 = new javax.swing.JLabel();
        st10 = new javax.swing.JLabel();
        st11 = new javax.swing.JLabel();
        st12 = new javax.swing.JLabel();
        st13 = new javax.swing.JLabel();
        st14 = new javax.swing.JLabel();
        st15 = new javax.swing.JLabel();
        st16 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        tctPassengerName = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        txtPassengerContact = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        tctCoachTime = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        txtCoachCode = new javax.swing.JTextField();
        btnReset = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        Title.setBackground(new java.awt.Color(0, 51, 51));

        busName.setFont(new java.awt.Font("Segoe UI Semilight", 1, 48)); // NOI18N
        busName.setForeground(new java.awt.Color(255, 255, 255));
        busName.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        busName.setText("Bus Name");

        javax.swing.GroupLayout TitleLayout = new javax.swing.GroupLayout(Title);
        Title.setLayout(TitleLayout);
        TitleLayout.setHorizontalGroup(
            TitleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, TitleLayout.createSequentialGroup()
                .addContainerGap(373, Short.MAX_VALUE)
                .addComponent(busName, javax.swing.GroupLayout.PREFERRED_SIZE, 382, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(357, 357, 357))
        );
        TitleLayout.setVerticalGroup(
            TitleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TitleLayout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(busName)
                .addContainerGap(60, Short.MAX_VALUE))
        );

        btnBook.setBackground(new java.awt.Color(0, 51, 51));
        btnBook.setFont(new java.awt.Font("Sitka Small", 1, 24)); // NOI18N
        btnBook.setForeground(new java.awt.Color(255, 255, 255));
        btnBook.setText("Next");
        btnBook.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBookActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Segoe UI Semilight", 1, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 51, 51));
        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel7.setText("Name");

        jPanel2.setBackground(new java.awt.Color(0, 51, 51));

        st1.setFont(new java.awt.Font("Segoe UI Semilight", 1, 24)); // NOI18N
        st1.setForeground(new java.awt.Color(0, 204, 51));
        st1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        st1.setText("A1");
        st1.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel3.setFont(new java.awt.Font("Segoe UI Semilight", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(233, 41, 79));
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("*Red marked Signed Already Booked ");

        st2.setFont(new java.awt.Font("Segoe UI Semilight", 1, 24)); // NOI18N
        st2.setForeground(new java.awt.Color(0, 204, 0));
        st2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        st2.setText("A2");
        st2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        st3.setFont(new java.awt.Font("Segoe UI Semilight", 1, 24)); // NOI18N
        st3.setForeground(new java.awt.Color(0, 204, 0));
        st3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        st3.setText("A3");
        st3.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        st4.setFont(new java.awt.Font("Segoe UI Semilight", 1, 24)); // NOI18N
        st4.setForeground(new java.awt.Color(0, 204, 0));
        st4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        st4.setText("A4");
        st4.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        st5.setFont(new java.awt.Font("Segoe UI Semilight", 1, 24)); // NOI18N
        st5.setForeground(new java.awt.Color(0, 204, 0));
        st5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        st5.setText("B1");
        st5.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        st6.setFont(new java.awt.Font("Segoe UI Semilight", 1, 24)); // NOI18N
        st6.setForeground(new java.awt.Color(0, 204, 0));
        st6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        st6.setText("B2");
        st6.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        st7.setFont(new java.awt.Font("Segoe UI Semilight", 1, 24)); // NOI18N
        st7.setForeground(new java.awt.Color(0, 204, 0));
        st7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        st7.setText("B3");
        st7.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        st8.setFont(new java.awt.Font("Segoe UI Semilight", 1, 24)); // NOI18N
        st8.setForeground(new java.awt.Color(0, 204, 0));
        st8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        st8.setText("B4");
        st8.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        st9.setFont(new java.awt.Font("Segoe UI Semilight", 1, 24)); // NOI18N
        st9.setForeground(new java.awt.Color(0, 204, 0));
        st9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        st9.setText("C1");
        st9.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        st10.setFont(new java.awt.Font("Segoe UI Semilight", 1, 24)); // NOI18N
        st10.setForeground(new java.awt.Color(0, 204, 0));
        st10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        st10.setText("C2");
        st10.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        st11.setFont(new java.awt.Font("Segoe UI Semilight", 1, 24)); // NOI18N
        st11.setForeground(new java.awt.Color(0, 204, 0));
        st11.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        st11.setText("C3");
        st11.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        st12.setFont(new java.awt.Font("Segoe UI Semilight", 1, 24)); // NOI18N
        st12.setForeground(new java.awt.Color(0, 204, 0));
        st12.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        st12.setText("C4");
        st12.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        st13.setFont(new java.awt.Font("Segoe UI Semilight", 1, 24)); // NOI18N
        st13.setForeground(new java.awt.Color(0, 204, 0));
        st13.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        st13.setText("D1");
        st13.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        st14.setFont(new java.awt.Font("Segoe UI Semilight", 1, 24)); // NOI18N
        st14.setForeground(new java.awt.Color(0, 204, 0));
        st14.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        st14.setText("D2");
        st14.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        st15.setFont(new java.awt.Font("Segoe UI Semilight", 1, 24)); // NOI18N
        st15.setForeground(new java.awt.Color(0, 204, 0));
        st15.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        st15.setText("D3");
        st15.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        st16.setFont(new java.awt.Font("Segoe UI Semilight", 1, 24)); // NOI18N
        st16.setForeground(new java.awt.Color(0, 204, 0));
        st16.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        st16.setText("D4");
        st16.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel4.setFont(new java.awt.Font("Segoe UI Semilight", 1, 36)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("Select Seat");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap(44, Short.MAX_VALUE)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 323, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(47, 47, 47)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(st1, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(st2, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(st5, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(st6, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(st9, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(st10, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(st13, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(st14, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(st11, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(st12, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(st7, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(st8, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(st3, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(st4, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(2, 2, 2)
                                .addComponent(st15, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(st16, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addGap(56, 56, 56))
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                    .addContainerGap(99, Short.MAX_VALUE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 231, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(93, 93, 93)))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(96, 96, 96)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(st1)
                    .addComponent(st2)
                    .addComponent(st3)
                    .addComponent(st4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(st5)
                    .addComponent(st6)
                    .addComponent(st7)
                    .addComponent(st8))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(st9)
                    .addComponent(st10)
                    .addComponent(st11)
                    .addComponent(st12))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(st13)
                    .addComponent(st14)
                    .addComponent(st15)
                    .addComponent(st16))
                .addGap(45, 45, 45)
                .addComponent(jLabel3)
                .addContainerGap(52, Short.MAX_VALUE))
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel2Layout.createSequentialGroup()
                    .addGap(21, 21, 21)
                    .addComponent(jLabel4)
                    .addContainerGap(326, Short.MAX_VALUE)))
        );

        tctPassengerName.setFont(new java.awt.Font("Segoe UI Semilight", 1, 18)); // NOI18N
        tctPassengerName.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        jLabel8.setFont(new java.awt.Font("Segoe UI Semilight", 1, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 51, 51));
        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel8.setText("Contact");

        txtPassengerContact.setFont(new java.awt.Font("Segoe UI Semilight", 1, 18)); // NOI18N
        txtPassengerContact.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        jLabel9.setFont(new java.awt.Font("Segoe UI Semilight", 1, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 51, 51));
        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel9.setText("Time");

        tctCoachTime.setFont(new java.awt.Font("Segoe UI Semilight", 1, 18)); // NOI18N
        tctCoachTime.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        jLabel10.setFont(new java.awt.Font("Segoe UI Semilight", 1, 18)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(0, 51, 51));
        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel10.setText("Coach Code");

        txtCoachCode.setFont(new java.awt.Font("Segoe UI Semilight", 1, 18)); // NOI18N
        txtCoachCode.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        btnReset.setBackground(new java.awt.Color(0, 51, 51));
        btnReset.setFont(new java.awt.Font("Sitka Small", 1, 24)); // NOI18N
        btnReset.setForeground(new java.awt.Color(255, 255, 255));
        btnReset.setText("Reset");
        btnReset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnResetActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(Title, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(51, 51, 51)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(76, 76, 76)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addGap(148, 148, 148)
                                    .addComponent(tctPassengerName, javax.swing.GroupLayout.PREFERRED_SIZE, 309, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addGap(25, 25, 25)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                            .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(26, 26, 26)
                                            .addComponent(tctCoachTime, javax.swing.GroupLayout.PREFERRED_SIZE, 309, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                            .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(26, 26, 26)
                                            .addComponent(txtPassengerContact, javax.swing.GroupLayout.PREFERRED_SIZE, 309, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(txtCoachCode, javax.swing.GroupLayout.PREFERRED_SIZE, 309, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(25, 25, 25)
                                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnBook, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(27, 27, 27)
                        .addComponent(btnReset, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(113, 113, 113))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(Title, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(123, 123, 123)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(164, 164, 164)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtCoachCode, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tctPassengerName, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtPassengerContact, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tctCoachTime, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(60, 60, 60)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnBook)
                            .addComponent(btnReset))))
                .addGap(0, 94, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    public void getAll() {
//        Name = txtName.getText();
//        Destination = txtDest.getText();
//        time = String.valueOf(txtTime.getSelectedItem());
//        Code = txtCode.getText();

    }

    public void rest() {
//        txtName.setText("");
//        txtCode.setText("");
//        txtDest.setText("");
//        txtTime.setSelectedItem(null);
//        txtPrice.setText("");

    }
    private void btnBookActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBookActionPerformed
//        getAll();
//        Price = Integer.parseInt(txtPrice.getText());
//        //setting values
//        CoachModel c = new CoachModel();
//        c.setName(Name);
//        c.setDestination(Destination);
//        c.setTime(time);
//        c.setPrice(Price);
//        c.setCode(Code);
//        System.out.println(Price);
//        int status = cServ.save(c);
//        if (status == 1) {
//            JOptionPane.showMessageDialog(rootPane, "Coach Created Successfully!!!");
//        } else {
//            JOptionPane.showMessageDialog(rootPane, "Coach Saving Failed!!!");
//        }
//        rest();
    }//GEN-LAST:event_btnBookActionPerformed

    private void btnResetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnResetActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnResetActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(SeatBookingController.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(SeatBookingController.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(SeatBookingController.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(SeatBookingController.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                SeatBookingController h = new SeatBookingController();
                h.setLocationRelativeTo(null);
                h.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Title;
    private javax.swing.JButton btnBook;
    private javax.swing.JButton btnReset;
    private javax.swing.JLabel busName;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel st1;
    private javax.swing.JLabel st10;
    private javax.swing.JLabel st11;
    private javax.swing.JLabel st12;
    private javax.swing.JLabel st13;
    private javax.swing.JLabel st14;
    private javax.swing.JLabel st15;
    private javax.swing.JLabel st16;
    private javax.swing.JLabel st2;
    private javax.swing.JLabel st3;
    private javax.swing.JLabel st4;
    private javax.swing.JLabel st5;
    private javax.swing.JLabel st6;
    private javax.swing.JLabel st7;
    private javax.swing.JLabel st8;
    private javax.swing.JLabel st9;
    private javax.swing.JTextField tctCoachTime;
    private javax.swing.JTextField tctPassengerName;
    private javax.swing.JTextField txtCoachCode;
    private javax.swing.JTextField txtPassengerContact;
    // End of variables declaration//GEN-END:variables
}
