package com.dao;

import com.common.CommonDao;
import com.model.CoachModel;
import com.util.DbConnect;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class FindBusDao implements CommonDao<CoachModel> {

    Connection con;
    Statement st;
    PreparedStatement ps;
    ResultSet rs;

    @Override
    public int save(CoachModel t) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int search(CoachModel t) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int update() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<CoachModel> getAll() {
        try {
            String sql = "select * from honda where";
            con = DbConnect.getConnect();
            st = con.createStatement();
            rs = st.executeQuery(sql);
            List<CoachModel> hondaList = new ArrayList<CoachModel>();
            System.out.println(rs.getString("name"));
            while (rs.next()) {
                CoachModel e = new CoachModel();
                e.setName(rs.getString("name"));
                e.setCode(rs.getString("code"));
                e.setPrice(rs.getInt("price"));
                e.setDestination(rs.getString("destination"));
                e.setTime(rs.getString("cTime"));
                
                hondaList.add(e);
            }
            con.close();
            return hondaList;
        } catch (Exception e) {
        }
        return null;
    }
}
