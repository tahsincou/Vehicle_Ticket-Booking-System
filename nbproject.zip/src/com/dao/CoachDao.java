package com.dao;

import com.common.CommonDao;
import com.model.CoachModel;
import com.util.DbConnect;
import java.sql.*;
import java.util.List;

public class CoachDao implements CommonDao<CoachModel> {

    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    Statement st;

    @Override
    public int save(CoachModel t) {
        try {
            String sql = "insert into invent.coach (name, destination, price,cTime,code) values(?,?,?,?,?)";
            con = DbConnect.getConnect();
            ps = con.prepareStatement(sql);
            ps.setString(1, t.getName());
            ps.setString(2, t.getDestination());
            ps.setInt(3, t.getPrice());
            ps.setString(4, t.getTime());
            ps.setString(5, t.getCode());
            int status = ps.executeUpdate();
            return status;
        } catch (Exception e) {
            e.printStackTrace();

        }
        return 0;
    }

    @Override
    public int search(CoachModel t) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int update() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<CoachModel> getAll() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
